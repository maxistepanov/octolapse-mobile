Choose the font size for the overlay.  Note that the higher your image resolution is, the larger your font size will need to be.

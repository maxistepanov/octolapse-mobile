Apply a color effect to your current image.

For the Raspberry Pi camera module v2 - Some color effects will be affected by the CbCr setting.  These are Aqua, Black and White, Sepia or Set CbCr.  The CbCr can be adjusted AFTER setting the color effect. Due to the ordering issue, it's possible that Octolapse may not apply the settings correctly, giving you an inconsistent effect after reboots or before a new print.  This issue is being investigated, and if at all possible, will be resolved.  For now I recommend that you do NOT use the Color Effects listed above.

For machines with multiple extruders OR machines with a shared extruder that supports multiple materials (like the Prusa MMU), you will need to set the number of extruders equal to the number of nozzles or materials.

Users with a single extruder that have a filament fuser (like the Mosaic Palette) should set this to 1.

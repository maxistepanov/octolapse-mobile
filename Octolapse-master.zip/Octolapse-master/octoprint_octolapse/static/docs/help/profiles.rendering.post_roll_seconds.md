Copies the last frame of the timelapse so that it shows for the number of seconds entered to prevent an abrupt ending to your timelapse video.

Here you can browse all of your timelapse videos.  The video directory defaults to the Octoprint timelapse directory, but can be changed within the Octolapse main settings.  Note that by default both Octolapse and OctoPrint timelapses will be visible (see **Main Settings** for information about the timelapse folder location).

### Download
To download a timelapse, simply click on the <i class="fa fa-download" title="Download Icon"></i>.  The timelapse will be downloaded by your browser.

### Delete
You can either delete a timelapse by clicking the <i class="fa fa-trash" title="Delete Icon"></i>, or by selecting one or more rows (via the checkbox or selection drop down), and clicking the **Delete** button.

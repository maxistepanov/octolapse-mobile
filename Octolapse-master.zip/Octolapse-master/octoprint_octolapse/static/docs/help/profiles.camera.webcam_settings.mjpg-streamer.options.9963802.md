Here you can color correct your images based on the temperature of your light source in kelvin.  A higher value will give you a more yellow image, while a lower value will give you a bluer image.  This is backwards from how the color temperature is labeled on a light bulb, so make a note of the difference.

On some cameras this setting will only function Auto White Balance Temperature is disabled, or when Auto White Balance Temperature is set to manual.  

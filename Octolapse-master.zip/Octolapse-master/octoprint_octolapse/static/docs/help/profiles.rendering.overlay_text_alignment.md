If multiple lines are entered in the overlay text box, this setting controls how they will be aligned.

For example:

```
  this
  text
   is
centered
```

```
this
text
is
left
aligned
```

```
   this
   text
     is
  right
aligned
```

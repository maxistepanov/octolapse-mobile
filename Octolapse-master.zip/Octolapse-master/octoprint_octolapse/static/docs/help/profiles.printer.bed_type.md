Choose from either rectangular or circular.  This setting is important because it is used to determine where to travel for snapshots.  Note that no matter what bed type you use, you will need to enter the max and min z (hight) coordinates.

#### Rectangular
When using a rectangular bed you must specify the min and max X and Y coordinates of your build volume.

#### Circular
When using a circular bed, you will only have to enter the XY diameter of your bed.

Controls the z-hop speed in cura version 4.2 and above.

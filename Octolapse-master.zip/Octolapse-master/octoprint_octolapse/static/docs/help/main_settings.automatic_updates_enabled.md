Octolapse can automatically update any profiles that have been imported from the profile repository.  Customized profiles cannot be updated.

When this setting is enabled, Octolapse will periodically check for profile updates form the repository.  You will be notified when there are new updates available.  Alternatively, you can check for updates manually in the main settings page.

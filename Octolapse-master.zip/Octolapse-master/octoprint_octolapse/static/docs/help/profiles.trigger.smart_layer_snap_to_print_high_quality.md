This mode allows Octolapse to select snap to print positions based on their print quality impacts.  This will improve quality for most prints, but will also result in a less stable timelapse. 

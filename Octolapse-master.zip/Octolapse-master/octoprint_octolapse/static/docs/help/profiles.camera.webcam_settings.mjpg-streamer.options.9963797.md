Flip (mirror) the image along the vertical axis.

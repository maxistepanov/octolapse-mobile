Allows you to adjust the auto exposure by a fixed number of f-stops over of above the camera's metering.  In a high contrast setting, this may improve detail.

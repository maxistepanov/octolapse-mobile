Adds image stabilization.  This is typically requires the camera to be zoomed in somewhat.

For the Raspberry Pi camera module v2 - Image stabilization will turn on OK, but I've not been able to disable it.  There is a work-around.  To turn off image stabilization, first uncheck the check box, then rotate or flip the camera image.  This should disable image stabilization.

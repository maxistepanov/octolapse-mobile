See if filament is primed, extruding, or if it's retracting or detracting.  This is more informational than anything.  I used this info panel while I was testing the *Extruder State Requriements* for the classic triggers, which tell Octolapse when it's allowed to or forbidden from taking snapshots based on the extruder state.  This is intended to improve print quality.

Note:  This info panel currently is only available when using real-time triggers.

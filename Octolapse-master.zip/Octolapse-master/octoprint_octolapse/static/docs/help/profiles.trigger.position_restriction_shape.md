Controls the shape of your position restriction.  All coordinates are absolute!

Two shapes are currently supported:

1.  Rectangle - The rectangle is defined by two corners, and is always axis aligned (no rotation option yet). A line is also permitted here (though not yet tested), but you either need to land exactly on the line, or you have to enable 'Calculate Intersections' to make this useful.
2.  Circle - Defined by the X,Y coordinate of the center and a radius (Not the diameter, this is very important).

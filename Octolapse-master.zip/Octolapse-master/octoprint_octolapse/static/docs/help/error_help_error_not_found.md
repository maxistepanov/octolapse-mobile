This is an Octolapse bug caused by an incorrectly supplied error key.  Please report the original error message, including the keys in the popup, to the octolapse github repository.

#### Report an Issue
If you are willing to help me debug your problem (which takes time and effort for both of us), please <a href="https://github.com/FormerLurker/Octolapse/wiki/V0.4---Reporting-An-Issue" title="How to report an issue in the Octolapse github repository" target="_blank">see this guide for reporting an issue</a>.

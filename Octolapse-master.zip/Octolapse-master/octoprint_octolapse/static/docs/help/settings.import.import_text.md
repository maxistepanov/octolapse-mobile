Paste in json text to import into Octolapse.  This json has a special formatting, which is automatically applied if you download the settings or profiles via Octolapse.

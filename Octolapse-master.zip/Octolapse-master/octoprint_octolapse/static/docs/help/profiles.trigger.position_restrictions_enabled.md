Enable or disable all added position restrictions.  If no position restrictions are entered, this setting has no effect.

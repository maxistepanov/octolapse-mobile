Here you can see when snapshots are being captured.  You'll see when the current trigger is waiting to come into position, or waiting on the extruder state.  This is a great place to debug problems with you snapshot profile, or to understand the effects of many of the snapshot settings.

Note:  This info panel currently is only available when using real-time triggers.

When enabled Octolapse will automatically download the most recent snapshot as soon as it is available.  When disabled you will have the option to refresh the image on-demand.  Disable this option if you need to save on bandwidth.

Note:  When this options is disabled you will not be able to view a preview animation of your timelapse while Octolapse is running.

Increase or decrease the zoom level of your camera.  If you plan to use pan and tilt, and your camera has digital pan and tilt, you may need to zoom in for those settings to work.

If your camera uses digital zoom, this option will reduce your image quality.  However, it is often very useful to zoom your camera while you are adjusting focus, since it will be easier to tell when your image is focused properly.

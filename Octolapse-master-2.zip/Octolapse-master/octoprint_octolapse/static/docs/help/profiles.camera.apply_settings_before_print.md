When enabled, Octolapse will apply all of your custom image preferences at the start of each print.  This ensures that your camera settings are consistent for every print.

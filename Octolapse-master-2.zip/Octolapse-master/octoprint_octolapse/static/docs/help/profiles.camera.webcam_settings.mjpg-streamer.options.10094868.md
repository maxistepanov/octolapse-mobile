Controls the white balance of the camera.  When set to 'Manual' your camera may have an option to allow you to manually adjust the white balance.

For the Raspberry Pi camera module v2 - When set to 'Auto', you will be able to adjust both the red and blue balance manually.

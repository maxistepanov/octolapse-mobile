When enabled the white balance will be adjusted automatically.  This could affect your snapshot delay.

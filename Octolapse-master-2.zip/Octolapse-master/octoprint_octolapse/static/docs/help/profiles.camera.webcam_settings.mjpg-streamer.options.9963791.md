Adjust the blue balance of your image.

For the Raspberry Pi camera module v2 - This setting will only affect your image if the 'White Balance, Auto & Preset' is set to 'Manual'. 

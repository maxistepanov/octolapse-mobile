One of the directories octolapse needs to capture snapshots and render timelapses failed testing.  Octolapse must have permission to read from, write to, and create directories within all three of the rquired folders.

### Steps to Resolve
Open the Octolapse **main settings** by navigating to the Octolapse tab and clicking the gear icon.  Find the **Folders** section and click the **Test** button next to each folder to see which folder is causing this problem.  If you have issues, click the help icon (a question mark) next to the folder setting for more information.

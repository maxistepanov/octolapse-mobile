This setting is used to detect 'Vase Mode' in Cura.

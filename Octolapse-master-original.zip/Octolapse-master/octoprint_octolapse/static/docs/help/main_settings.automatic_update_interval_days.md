Octolapse will check for updates once every 30 days by default.    Change this setting to alter the update interval

Note:  Octolapse always checks for updates when it is starting up.

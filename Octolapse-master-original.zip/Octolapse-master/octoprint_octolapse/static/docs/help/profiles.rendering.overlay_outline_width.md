Sets the width (number of outlines) of the overlay outline.  Note that the Outline Color must be non-transparent, and different from the overlay text color in order to be visible.

The method I used to add the outline is fairly primitive, but works well for smaller font widths.  If you set this too high the results will not look very good.  I may try to improve this in the future.

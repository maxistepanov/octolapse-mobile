Tells Octolapse that your slicer has retraction enabled.  If this is unchecked, Octolapse will not use retraction when traveling to the snapshot position, which will greatly impact print quality.

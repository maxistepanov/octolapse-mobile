Select the make of your printer.  If it is not listed, select 'Other'.  If you choose 'Other', Octolapse will not be able to automatically keep your printer updated with the latest settings.

If your make isn't listed, check back often, or submit a request to have your printer added [here](https://github.com/FormerLurker/Octolapse/issues/new).  I will be adding tutorials on how to create new printer profiles, and encouraging people to submit newly created profiles soon, and will update this help message as soon as it's available.

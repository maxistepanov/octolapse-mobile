Your current rendering profile has overlay text, but Octolapse could not locate the font path.  It's possible that you have imported a settings file that contained a font path that does not exist on your machine.

## Steps to Fix
Open your rendering profile, scroll down to **Overlay** and either delete the overlay text, or select a different font from the list.

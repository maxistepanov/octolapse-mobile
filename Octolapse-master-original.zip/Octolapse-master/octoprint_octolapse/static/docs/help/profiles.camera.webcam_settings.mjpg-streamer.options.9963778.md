Adjust the saturation of the webcam image.  Lower values have less saturation, higher values have more.

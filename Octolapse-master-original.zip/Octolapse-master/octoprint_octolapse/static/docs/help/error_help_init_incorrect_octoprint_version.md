You are using an older version of OctoPrint that is not supported by Octolapse.  

#### Upgrading OctoPrint

You can upgrade OctoPrint by opening the settings (wrench/spanner icon at the top of the OctoPrint webpage), selecting **Software Update** from the leftmost menu (under the **OCTOPRINT** heading), and clicking **Update** next to the OctoPrint item.  Reboot when prompted.

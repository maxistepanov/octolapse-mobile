Gcode files typically use millimeters per minute (mm/min) when instructing the printer how fast it should move.  Many slicers use millimeters per second (mm/sec), since the numbers are a bit more user friendly to read and type.  Use this setting to switch between the two for convenience

Note:  Some small rounding changes can occur when switching to/from each unit.

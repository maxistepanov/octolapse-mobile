I don't believe this affects mjpg-stremer in any way.

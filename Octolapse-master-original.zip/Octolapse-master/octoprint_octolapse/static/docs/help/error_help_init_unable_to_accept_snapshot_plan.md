This error is usually caused when a snapshot plan is accepted in another browser, but the current browser was not connected to octoprint when the plan was accepted.

Copies the first frame of the timelapse so that it shows for the number of seconds entered to prevent an abrupt start to your timelapse video.

Are your snapshots upside-down, rotated or transposed?  You can fix this with the snapshot transposition option.  These options are available:

* Flip Left and Right
* Flip Top and Bottom
* Rotate 90 Degrees
* Rotate 180 Degrees
* Rotate 270 Degrees
* Transpose

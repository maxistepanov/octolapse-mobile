Sets the exposure mode based on current conditions.   

For the Raspberry Pi camera module v2 - Scene mode overrides all manual exposure settings.  Set Scene to 'None' if you want to manually adjust your exposure.



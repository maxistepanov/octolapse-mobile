An unexpected exception occurred while starting Octolapse.  More details about where the exception occurred should be stored in plugin_octolapse.log, as long as error logging is enabled (see your current debug profile).

#### Report an Issue
Since this exception was not planned for, you may wish to submit a bug report.  If you are willing to help me debug your problem (which takes time and effort for both of us), please <a href="https://github.com/FormerLurker/Octolapse/wiki/V0.4---Reporting-An-Issue" title="How to report an issue in the Octolapse github repository" target="_blank">see this guide for reporting an issue</a>.  When you submit your issue, be sure to include your log file (plugin_octolapse.log).


Here you can see where Octoprint thinks your printhead will be based on the commands that have queued.  You can also see any offsets caused by the G21 command.

Note:  This info panel currently is only available when using real-time triggers.

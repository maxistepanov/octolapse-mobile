This option may improve the image quality/color if the target is illuminated from behind. 

Rotate your image.

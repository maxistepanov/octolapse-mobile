Sets the method by which the camera will calculate auto exposure.

For the Raspberry Pi camera module v2 - This setting will only have an effect if 'Auto Exposure' is enabled.  It might also affect the exposure if the 'Scene' mode is not set to none, but this has not been verified.

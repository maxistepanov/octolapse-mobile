Your gcode file, created from Simplify3D, contains more than 8 extruders.  A max of 8 extruders is currently supported.

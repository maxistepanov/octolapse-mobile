Sets the color of the text, including an optional transparency value so that you can see your timelapse through the overlay.  Just don't set the transparency too low, or you won't be able to read it!
